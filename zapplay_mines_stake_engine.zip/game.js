
const BOARD_SIZE = 5;
const TOTAL_TILES = BOARD_SIZE * BOARD_SIZE;

let gameState = {
  active: false,
  mines: new Set(),
  revealedSafe: new Set(),
  mineCount: 3,
  betAmount: 0.00000010,
  currentMultiplier: 1.0,
  busted: false
};

const boardEl = document.getElementById("board");
const mineCountInput = document.getElementById("mineCount");
const mineCountLabel = document.getElementById("mineCountLabel");
const betAmountInput = document.getElementById("betAmount");
const multiplierEl = document.getElementById("multiplier");
const cashoutPreviewEl = document.getElementById("cashoutPreview");
const statusEl = document.getElementById("status");
const startBtn = document.getElementById("startBtn");
const cashoutBtn = document.getElementById("cashoutBtn");
const resetBtn = document.getElementById("resetBtn");

function formatAmount(val) {
  return Number(val).toFixed(8);
}

function formatMultiplier(val) {
  return Number(val).toFixed(2) + "x";
}

// Slightly aggressive multiplier model
function calculateMultiplier(safeRevealedCount, mineCount) {
  if (safeRevealedCount <= 0) return 1.0;
  const riskFactor = mineCount / TOTAL_TILES; // 0-~1
  const base = 1.18 + riskFactor * 0.55; // 1.18 - 1.73
  const result = Math.pow(base, safeRevealedCount) * 0.99; // 1% house edge baked in
  return Number(result.toFixed(4));
}

function updateMineCountLabel() {
  gameState.mineCount = Number(mineCountInput.value);
  mineCountLabel.textContent = gameState.mineCount;
  updateMultiplierAndPreview();
}

function updateBetAmount() {
  const raw = Number(betAmountInput.value);
  if (!isFinite(raw) || raw <= 0) return;
  gameState.betAmount = raw;
  updateMultiplierAndPreview();
}

function updateMultiplierAndPreview() {
  const m = calculateMultiplier(gameState.revealedSafe.size, gameState.mineCount);
  gameState.currentMultiplier = m;
  multiplierEl.textContent = formatMultiplier(m);
  const cashout = gameState.betAmount * m;
  cashoutPreviewEl.textContent = formatAmount(cashout);
}

function initBoard() {
  boardEl.innerHTML = "";
  for (let i = 0; i < TOTAL_TILES; i++) {
    const tile = document.createElement("button");
    tile.className = "zp-tile inactive";
    tile.dataset.index = String(i);
    tile.type = "button";
    tile.addEventListener("click", () => onTileClick(i));
    boardEl.appendChild(tile);
  }
}

function armBoard() {
  const tiles = boardEl.querySelectorAll(".zp-tile");
  tiles.forEach((tile) => {
    tile.classList.remove("inactive", "revealed-safe", "mine-hit", "mine");
    tile.textContent = "";
  });

  gameState.mines.clear();
  gameState.revealedSafe.clear();
  gameState.busted = false;

  while (gameState.mines.size < gameState.mineCount) {
    const idx = Math.floor(Math.random() * TOTAL_TILES);
    gameState.mines.add(idx);
  }

  gameState.active = true;
  updateMultiplierAndPreview();
  refreshTileActivity();
  statusEl.textContent = "Game live. Reveal safe tiles or cash out anytime.";
  cashoutBtn.disabled = false;
}

function refreshTileActivity() {
  const tiles = boardEl.querySelectorAll(".zp-tile");
  tiles.forEach((tile) => {
    if (!gameState.active) {
      tile.classList.add("inactive");
    } else {
      const idx = Number(tile.dataset.index);
      if (gameState.revealedSafe.has(idx) || gameState.mines.has(idx) && gameState.busted) {
        tile.classList.add("inactive");
      } else {
        tile.classList.remove("inactive");
      }
    }
  });
}

function onTileClick(index) {
  if (!gameState.active || gameState.busted) return;
  if (gameState.revealedSafe.has(index)) return;

  const tile = boardEl.querySelector(`.zp-tile[data-index="${index}"]`);
  if (!tile) return;

  if (gameState.mines.has(index)) {
    // Hit a mine
    tile.classList.add("mine-hit");
    tile.textContent = "💣";
    revealAllMines();
    gameState.busted = true;
    gameState.active = false;
    gameState.currentMultiplier = 0;
    multiplierEl.textContent = "0.00x";
    cashoutPreviewEl.textContent = formatAmount(0);
    cashoutBtn.disabled = true;
    statusEl.textContent = "Boom. You hit a mine.";
    refreshTileActivity();
    return;
  }

  // Safe tile
  gameState.revealedSafe.add(index);
  tile.classList.add("revealed-safe");
  tile.textContent = "⚡";
  updateMultiplierAndPreview();
  refreshTileActivity();

  if (gameState.revealedSafe.size >= TOTAL_TILES - gameState.mineCount) {
    gameState.active = false;
    cashoutBtn.disabled = false;
    statusEl.textContent = "You cleared the entire board. Cash out the max!";
    refreshTileActivity();
  } else {
    statusEl.textContent = "Nice hit. Keep going or cash out.";
  }
}

function revealAllMines() {
  const tiles = boardEl.querySelectorAll(".zp-tile");
  tiles.forEach((tile) => {
    const idx = Number(tile.dataset.index);
    if (gameState.mines.has(idx)) {
      if (!tile.classList.contains("mine-hit")) {
        tile.classList.add("mine");
        tile.textContent = "💣";
      }
    }
  });
}

function startGame() {
  const rawBet = Number(betAmountInput.value);
  if (!isFinite(rawBet) || rawBet <= 0) {
    statusEl.textContent = "Enter a valid bet amount.";
    return;
  }
  gameState.betAmount = rawBet;
  armBoard();
}

function cashout() {
  if (!gameState.revealedSafe.size || gameState.currentMultiplier <= 1 || !gameState.betAmount) {
    statusEl.textContent = "Reveal at least one safe tile before cashing out.";
    return;
  }
  const payout = gameState.betAmount * gameState.currentMultiplier;
  gameState.active = false;
  cashoutBtn.disabled = true;
  statusEl.textContent = `Cashed out at ${formatMultiplier(gameState.currentMultiplier)} for ${formatAmount(payout)}.`;
  refreshTileActivity();

  // NOTE: In a real Stake Engine integration, trigger your payout callback here.
}

function resetGame() {
  gameState.active = false;
  gameState.mines.clear();
  gameState.revealedSafe.clear();
  gameState.busted = false;
  gameState.currentMultiplier = 1.0;
  updateMultiplierAndPreview();
  initBoard();
  statusEl.textContent = "Place your bet and hit Start.";
  cashoutBtn.disabled = true;
}

mineCountInput.addEventListener("input", updateMineCountLabel);
betAmountInput.addEventListener("input", updateBetAmount);
startBtn.addEventListener("click", startGame);
cashoutBtn.addEventListener("click", cashout);
resetBtn.addEventListener("click", resetGame);

initBoard();
updateMineCountLabel();
updateBetAmount();
